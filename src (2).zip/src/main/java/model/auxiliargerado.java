package model;

public class auxiliargerado {
    private String tamanho;
    private String sabor;
    private Float valortotalp;
    private Long idPedido;
    private Long idcliente;
    private Long idPizza;
    private String nomebebida;
    private Float valortotalb;
    private Long quantidade;
    private Long idclinte;
    private Long idbebida;

    private Long idpedido;

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public String getSabor() {
        return sabor;
    }

    public void setSabor(String sabor) {
        this.sabor = sabor;
    }

    public Float getValortotalp() {
        return valortotalp;
    }

    public void setValortotalp(Float valortotalp) {
        this.valortotalp = valortotalp;
    }

    public Long getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(Long idPedido) {
        this.idPedido = idPedido;
    }

    public Long getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(Long idcliente) {
        this.idcliente = idcliente;
    }

    public Long getIdPizza() {
        return idPizza;
    }

    public void setIdPizza(Long idPizza) {
        this.idPizza = idPizza;
    }

    public String getNomebebida() {
        return nomebebida;
    }

    public void setNomebebida(String nomebebida) {
        this.nomebebida = nomebebida;
    }

    public Float getValortotalb() {
        return valortotalb;
    }

    public void setValortotalb(Float valortotalb) {
        this.valortotalb = valortotalb;
    }

    public Long getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Long quantidade) {
        this.quantidade = quantidade;
    }

    public Long getIdclinte() {
        return idclinte;
    }

    public void setIdclinte(Long idclinte) {
        this.idclinte = idclinte;
    }

    public Long getIdbebida() {
        return idbebida;
    }

    public void setIdbebida(Long idbebida) {
        this.idbebida = idbebida;
    }

    public Long getIdpedido() {
        return idpedido;
    }

    public void setIdpedido(Long idpedido) {
        this.idpedido = idpedido;
    }
}
